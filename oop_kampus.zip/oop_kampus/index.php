<?php

// =======================
// CLASS PARENT (USER)
// =======================
class User {

    // Encapsulation (private)
    private $nama;
    private $email;

    // Constructor
    public function __construct($nama, $email){
        $this->nama = $nama;
        $this->email = $email;
    }

    // Setter dan Getter
    public function setNama($nama){
        $this->nama = $nama;
    }

    public function getNama(){
        return $this->nama;
    }

    public function setEmail($email){
        $this->email = $email;
    }

    public function getEmail(){
        return $this->email;
    }
}


// =======================
// CLASS MAHASISWA
// =======================
class Mahasiswa extends User {

    private $nim;

    public function __construct($nama, $email, $nim){
        parent::__construct($nama, $email);
        $this->nim = $nim;
    }

    public function getNim(){
        return $this->nim;
    }
}


// =======================
// CLASS DOSEN
// =======================
class Dosen extends User {

    private $nidn;

    public function __construct($nama, $email, $nidn){
        parent::__construct($nama, $email);
        $this->nidn = $nidn;
    }

    public function getNidn(){
        return $this->nidn;
    }
}


// =======================
// MEMBUAT OBJECT
// =======================

// object mahasiswa
$mhs = new Mahasiswa("Budi Santoso", "budi@gmail.com", "220101");

// object dosen
$dosen = new Dosen("Andi Wijaya", "andi@gmail.com", "198765");


// =======================
// MENAMPILKAN DATA
// =======================

echo "<h3>Data Mahasiswa</h3>";
echo "Nama : " . $mhs->getNama() . "<br>";
echo "Email : " . $mhs->getEmail() . "<br>";
echo "NIM : " . $mhs->getNim() . "<br>";

echo "<br>";

echo "<h3>Data Dosen</h3>";
echo "Nama : " . $dosen->getNama() . "<br>";
echo "Email : " . $dosen->getEmail() . "<br>";
echo "NIDN : " . $dosen->getNidn() . "<br>";

?>